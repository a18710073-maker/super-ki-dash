class_name CartoonFactory
extends RefCounted

static var _toon_shader: Shader = null
static var _outline_shader: Shader = null
static var _material_cache: Dictionary = {}
static var _curve_y: float = 0.00145
static var _curve_x: float = 0.0

static func _ensure_shaders() -> void:
	if _toon_shader == null:
		_toon_shader = Shader.new()
		_toon_shader.code = """
shader_type spatial;
render_mode cull_back, diffuse_toon, specular_toon;

uniform vec4 albedo_color : source_color = vec4(1.0);
uniform vec4 emission_color : source_color = vec4(0.0);
uniform float emission_energy : hint_range(0.0, 5.0) = 0.0;
uniform float curve_y = 0.00145;
uniform float curve_x = 0.0;

void vertex() {
	vec4 world_pos = MODEL_MATRIX * vec4(VERTEX, 1.0);
	float dist = max(0.0, -world_pos.z - 4.0);
	float dist_sq = dist * dist;
	world_pos.y -= dist_sq * curve_y;
	world_pos.x += dist_sq * curve_x;
	VERTEX = (inverse(MODEL_MATRIX) * world_pos).xyz;
}

void fragment() {
	ALBEDO = albedo_color.rgb;
	ROUGHNESS = 0.45;
	METALLIC = 0.05;
	if (emission_energy > 0.0) {
		EMISSION = emission_color.rgb * emission_energy;
	}
}

void light() {
	float ndotl = dot(NORMAL, LIGHT);
	float toon_band = smoothstep(-0.08, 0.06, ndotl);
	float shade = mix(0.56, 1.05, toon_band);
	float rim = pow(1.0 - clamp(dot(NORMAL, VIEW), 0.0, 1.0), 3.0) * 0.24;
	DIFFUSE_LIGHT += ALBEDO * LIGHT_COLOR * ATTENUATION * (shade + rim);
}
"""

	if _outline_shader == null:
		_outline_shader = Shader.new()
		_outline_shader.code = """
shader_type spatial;
render_mode cull_front, unshaded;

uniform vec4 outline_color : source_color = vec4(0.08, 0.08, 0.14, 1.0);
uniform float outline_width : hint_range(0.0, 0.1) = 0.022;
uniform float curve_y = 0.00145;
uniform float curve_x = 0.0;

void vertex() {
	VERTEX += NORMAL * outline_width;
	vec4 world_pos = MODEL_MATRIX * vec4(VERTEX, 1.0);
	float dist = max(0.0, -world_pos.z - 4.0);
	float dist_sq = dist * dist;
	world_pos.y -= dist_sq * curve_y;
	world_pos.x += dist_sq * curve_x;
	VERTEX = (inverse(MODEL_MATRIX) * world_pos).xyz;
}

void fragment() {
	ALBEDO = outline_color.rgb;
}
"""

static func set_world_curve(cx: float, cy: float) -> void:
	_curve_x = cx
	_curve_y = cy
	for key in _material_cache.keys():
		var mat: ShaderMaterial = _material_cache[key]
		if is_instance_valid(mat):
			mat.set_shader_parameter("curve_x", cx)
			mat.set_shader_parameter("curve_y", cy)
			if mat.next_pass is ShaderMaterial:
				var out_mat := mat.next_pass as ShaderMaterial
				out_mat.set_shader_parameter("curve_x", cx)
				out_mat.set_shader_parameter("curve_y", cy)

static func make_toon_material(color: Color, emission_strength: float = 0.0, outline_width: float = 0.020, unique: bool = false) -> ShaderMaterial:
	_ensure_shaders()
	var key := "%s_%.2f_%.3f" % [color.to_html(), emission_strength, outline_width]
	if not unique and _material_cache.has(key):
		return _material_cache[key]

	var mat := ShaderMaterial.new()
	mat.shader = _toon_shader
	mat.set_shader_parameter("albedo_color", color)
	mat.set_shader_parameter("emission_color", color)
	mat.set_shader_parameter("emission_energy", emission_strength)
	mat.set_shader_parameter("curve_y", _curve_y)
	mat.set_shader_parameter("curve_x", _curve_x)

	if outline_width > 0.0:
		var outline_mat := ShaderMaterial.new()
		outline_mat.shader = _outline_shader
		outline_mat.set_shader_parameter("outline_width", outline_width)
		outline_mat.set_shader_parameter("curve_y", _curve_y)
		outline_mat.set_shader_parameter("curve_x", _curve_x)
		mat.next_pass = outline_mat

	if not unique:
		_material_cache[key] = mat
	return mat

static func add_box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation_degrees = rot_deg
	parent.add_child(mi)
	return mi

static func add_cylinder(parent: Node3D, top_r: float, bottom_r: float, height: float, pos: Vector3, mat: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = top_r
	mesh.bottom_radius = bottom_r
	mesh.height = height
	mesh.radial_segments = 16
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.rotation_degrees = rot_deg
	parent.add_child(mi)
	return mi

static func add_sphere(parent: Node3D, radius: float, pos: Vector3, mat: Material, scale_vec: Vector3 = Vector3.ONE) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var mesh := SphereMesh.new()
	mesh.radius = radius
	mesh.height = radius * 2.0
	mesh.radial_segments = 16
	mesh.rings = 10
	mi.mesh = mesh
	mi.material_override = mat
	mi.position = pos
	mi.scale = scale_vec
	parent.add_child(mi)
	return mi

static func build_character_rig(runner_id: String = "koku") -> Dictionary:
	var root := Node3D.new()
	root.name = "CharacterVisual"

	var is_vex := (runner_id == "vex")
	var is_chaser := (runner_id == "chaser")

	var skin_mat := make_toon_material(Color(1.0, 0.80, 0.64), 0.0, 0.018)
	var hair_mat := make_toon_material(Color(0.08, 0.08, 0.12), 0.0, 0.018, true)
	var eye_mat := make_toon_material(Color(0.06, 0.06, 0.10), 0.0, 0.0)

	var gi_orange := make_toon_material(Color(1.0, 0.36, 0.04), 0.0, 0.020)
	var gi_blue := make_toon_material(Color(0.10, 0.28, 0.78), 0.0, 0.020)
	var armor_white := make_toon_material(Color(0.96, 0.96, 0.98), 0.0, 0.020)
	var armor_gold := make_toon_material(Color(1.0, 0.78, 0.12), 0.0, 0.016)
	var boot_white := make_toon_material(Color(0.95, 0.95, 0.97), 0.0, 0.018)
	var guard_navy := make_toon_material(Color(0.12, 0.18, 0.36), 0.0, 0.020)

	var torso_pivot := Node3D.new()
	torso_pivot.position = Vector3(0, 1.05, 0)
	root.add_child(torso_pivot)

	if is_chaser:
		add_box(torso_pivot, Vector3(0.68, 0.74, 0.42), Vector3.ZERO, guard_navy)
		add_box(torso_pivot, Vector3(0.70, 0.14, 0.44), Vector3(0, -0.22, 0), armor_gold)
	elif is_vex:
		add_box(torso_pivot, Vector3(0.60, 0.70, 0.36), Vector3.ZERO, gi_blue)
		add_box(torso_pivot, Vector3(0.64, 0.56, 0.40), Vector3(0, 0.05, 0), armor_white)
		add_box(torso_pivot, Vector3(0.56, 0.16, 0.42), Vector3(0, 0.14, 0), armor_gold)
		add_box(torso_pivot, Vector3(0.56, 0.14, 0.42), Vector3(0, -0.08, 0), armor_gold)
		add_box(torso_pivot, Vector3(0.30, 0.12, 0.42), Vector3(-0.44, 0.34, 0), armor_white, Vector3(0, 0, 16))
		add_box(torso_pivot, Vector3(0.30, 0.12, 0.42), Vector3(0.44, 0.34, 0), armor_white, Vector3(0, 0, -16))
	else:
		add_box(torso_pivot, Vector3(0.62, 0.72, 0.38), Vector3.ZERO, gi_orange)
		add_box(torso_pivot, Vector3(0.32, 0.24, 0.40), Vector3(0, 0.24, 0), gi_blue)
		add_box(torso_pivot, Vector3(0.66, 0.14, 0.42), Vector3(0, -0.26, 0), gi_blue)
		var pole_mat := make_toon_material(Color(0.88, 0.14, 0.16), 0.0, 0.015)
		add_cylinder(torso_pivot, 0.055, 0.055, 1.35, Vector3(0.0, 0.06, 0.25), pole_mat, Vector3(0, 0, -34))

	var head_pivot := Node3D.new()
	head_pivot.position = Vector3(0, 0.56, 0)
	torso_pivot.add_child(head_pivot)
	add_sphere(head_pivot, 0.29, Vector3(0, 0.12, 0), skin_mat)

	if is_chaser:
		add_cylinder(head_pivot, 0.34, 0.30, 0.22, Vector3(0, 0.30, 0), guard_navy)
		add_box(head_pivot, Vector3(0.34, 0.05, 0.24), Vector3(0, 0.22, -0.26), hair_mat)
		add_sphere(head_pivot, 0.07, Vector3(0, 0.30, -0.31), armor_gold)
	elif is_vex:
		add_sphere(head_pivot, 0.30, Vector3(0, 0.18, 0.03), hair_mat, Vector3(1.02, 0.90, 1.04))
		add_box(head_pivot, Vector3(0.11, 0.06, 0.06), Vector3(-0.11, 0.12, -0.27), eye_mat, Vector3(0, 0, -10))
		add_box(head_pivot, Vector3(0.11, 0.06, 0.06), Vector3(0.11, 0.12, -0.27), eye_mat, Vector3(0, 0, 10))
		add_cylinder(head_pivot, 0.01, 0.24, 0.58, Vector3(0, 0.56, 0.05), hair_mat, Vector3(-8, 0, 0))
		add_cylinder(head_pivot, 0.01, 0.17, 0.48, Vector3(-0.16, 0.48, 0.04), hair_mat, Vector3(-6, 0, 18))
		add_cylinder(head_pivot, 0.01, 0.17, 0.48, Vector3(0.16, 0.48, 0.04), hair_mat, Vector3(-6, 0, -18))
		add_cylinder(head_pivot, 0.01, 0.14, 0.38, Vector3(0, 0.44, 0.22), hair_mat, Vector3(-28, 0, 0))
		var scouter_mat := make_toon_material(Color(0.12, 0.96, 0.38), 0.75, 0.01)
		add_box(head_pivot, Vector3(0.16, 0.09, 0.05), Vector3(-0.14, 0.13, -0.30), scouter_mat)
	else:
		add_sphere(head_pivot, 0.30, Vector3(0, 0.18, 0.03), hair_mat, Vector3(1.02, 0.90, 1.04))
		add_box(head_pivot, Vector3(0.11, 0.06, 0.06), Vector3(-0.11, 0.12, -0.27), eye_mat, Vector3(0, 0, -10))
		add_box(head_pivot, Vector3(0.11, 0.06, 0.06), Vector3(0.11, 0.12, -0.27), eye_mat, Vector3(0, 0, 10))
		add_cylinder(head_pivot, 0.01, 0.16, 0.46, Vector3(-0.28, 0.34, 0.04), hair_mat, Vector3(0, 0, 52))
		add_cylinder(head_pivot, 0.01, 0.16, 0.48, Vector3(0.28, 0.36, 0.04), hair_mat, Vector3(0, 0, -50))
		add_cylinder(head_pivot, 0.01, 0.15, 0.44, Vector3(-0.24, 0.20, 0.08), hair_mat, Vector3(0, 0, 76))
		add_cylinder(head_pivot, 0.01, 0.15, 0.44, Vector3(0.24, 0.20, 0.08), hair_mat, Vector3(0, 0, -76))
		add_cylinder(head_pivot, 0.01, 0.18, 0.46, Vector3(0.0, 0.46, 0.08), hair_mat, Vector3(-20, 0, 0))

	var arm_mat := guard_navy if is_chaser else (gi_blue if is_vex else skin_mat)
	var cuff_mat := armor_gold if is_chaser else (armor_white if is_vex else gi_blue)

	var left_arm := Node3D.new()
	left_arm.position = Vector3(-0.42, 0.26, 0)
	torso_pivot.add_child(left_arm)
	add_box(left_arm, Vector3(0.18, 0.44, 0.18), Vector3(0, -0.18, 0), arm_mat)
	add_box(left_arm, Vector3(0.20, 0.14, 0.20), Vector3(0, -0.40, 0), cuff_mat)
	add_sphere(left_arm, 0.10, Vector3(0, -0.50, 0), armor_white if is_vex else skin_mat)

	var right_arm := Node3D.new()
	right_arm.position = Vector3(0.42, 0.26, 0)
	torso_pivot.add_child(right_arm)
	add_box(right_arm, Vector3(0.18, 0.44, 0.18), Vector3(0, -0.18, 0), arm_mat)
	add_box(right_arm, Vector3(0.20, 0.14, 0.20), Vector3(0, -0.40, 0), cuff_mat)
	add_sphere(right_arm, 0.10, Vector3(0, -0.50, 0), armor_white if is_vex else skin_mat)

	var pants_mat := guard_navy if is_chaser else (gi_blue if is_vex else gi_orange)
	var shoe_mat := hair_mat if is_chaser else (boot_white if is_vex else gi_blue)

	var left_leg := Node3D.new()
	left_leg.position = Vector3(-0.17, 0.68, 0)
	root.add_child(left_leg)
	add_box(left_leg, Vector3(0.23, 0.48, 0.24), Vector3(0, -0.22, 0), pants_mat)
	add_box(left_leg, Vector3(0.25, 0.22, 0.36), Vector3(0, -0.52, -0.05), shoe_mat)

	var right_leg := Node3D.new()
	right_leg.position = Vector3(0.17, 0.68, 0)
	root.add_child(right_leg)
	add_box(right_leg, Vector3(0.23, 0.48, 0.24), Vector3(0, -0.22, 0), pants_mat)
	add_box(right_leg, Vector3(0.25, 0.22, 0.36), Vector3(0, -0.52, -0.05), shoe_mat)

	var board := Node3D.new()
	board.position = Vector3(0, 0.08, 0)
	board.visible = false
	root.add_child(board)
	var cloud_mat := make_toon_material(Color(1.0, 0.86, 0.12), 0.65, 0.022)
	add_sphere(board, 0.45, Vector3(0, 0, 0.0), cloud_mat, Vector3(1.1, 0.45, 1.8))
	add_sphere(board, 0.35, Vector3(-0.28, 0.04, 0.35), cloud_mat, Vector3(1.0, 0.5, 1.2))
	add_sphere(board, 0.35, Vector3(0.28, 0.04, 0.35), cloud_mat, Vector3(1.0, 0.5, 1.2))
	add_sphere(board, 0.30, Vector3(0.0, 0.02, -0.65), cloud_mat, Vector3(0.9, 0.45, 1.3))

	var aura := Node3D.new()
	aura.position = Vector3(0, 1.0, 0)
	aura.visible = false
	root.add_child(aura)
	var aura_mat := make_toon_material(Color(1.0, 0.92, 0.18), 1.1, 0.0)
	add_cylinder(aura, 0.72, 0.88, 0.10, Vector3(0, -0.75, 0), aura_mat)
	add_cylinder(aura, 0.62, 0.76, 0.08, Vector3(0, 0.0, 0), aura_mat)

	return {
		"root": root,
		"torso": torso_pivot,
		"head": head_pivot,
		"left_arm": left_arm,
		"right_arm": right_arm,
		"left_leg": left_leg,
		"right_leg": right_leg,
		"hoverboard": board,
		"aura": aura,
		"hair_mat": hair_mat
	}
