extends Node

## Manages looping Subway Surfers-inspired Anime Electro-Funk Music Tracks
## (menu_theme, run_theme_1, run_theme_2) with dynamic Super-Aura pitch boost,
## pause/gameover volume ducking, mute toggle, and procedural cartoon SFX.

var _music_player: AudioStreamPlayer
var _tracks: Dictionary = {}
var _current_track_key: String = ""
var music_muted: bool = false

var _players: Array[AudioStreamPlayer] = []
var _pool_index: int = 0
const POOL_SIZE := 6
const SAMPLE_RATE := 22050.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

	_music_player = AudioStreamPlayer.new()
	_music_player.volume_db = -5.0
	add_child(_music_player)

	_tracks["menu"] = load("res://assets/audio/menu_theme.wav")
	_tracks["run1"] = load("res://assets/audio/run_theme_1.wav")
	_tracks["run2"] = load("res://assets/audio/run_theme_2.wav")

	for i in range(POOL_SIZE):
		var p := AudioStreamPlayer.new()
		var gen := AudioStreamGenerator.new()
		gen.mix_rate = SAMPLE_RATE
		gen.buffer_length = 0.35
		p.stream = gen
		p.volume_db = -7.5
		add_child(p)
		_players.append(p)

	play_music("menu")

func play_music(track_key: String) -> void:
	if not _tracks.has(track_key):
		return
	if _current_track_key == track_key and _music_player.playing:
		return
	_current_track_key = track_key
	var stream: AudioStream = _tracks[track_key]
	if stream is AudioStreamWAV:
		(stream as AudioStreamWAV).loop_mode = AudioStreamWAV.LOOP_FORWARD
	_music_player.stream = stream
	_music_player.pitch_scale = 1.0
	if not music_muted:
		_music_player.play()

func set_music_muted(muted: bool) -> void:
	music_muted = muted
	if music_muted:
		_music_player.stop()
	elif _current_track_key != "":
		_music_player.play()

func toggle_music_mute() -> bool:
	set_music_muted(not music_muted)
	return music_muted

func _process(delta: float) -> void:
	if music_muted or _music_player == null:
		return
	if not _music_player.playing and _current_track_key != "":
		_music_player.play()

	# Dynamic volume & pitch response for Pause, Game Over, and Super Aura!
	var target_db := -5.0
	var target_pitch := 1.0
	if GameManager.state == GameManager.GameState.PAUSED:
		target_db = -16.0
		target_pitch = 0.94
	elif GameManager.state == GameManager.GameState.GAMEOVER:
		target_db = -14.0
		target_pitch = 0.88
	elif GameManager.state == GameManager.GameState.PLAYING and GameManager.is_super_mode_active():
		target_db = -3.5
		target_pitch = 1.06

	_music_player.volume_db = lerpf(_music_player.volume_db, target_db, delta * 6.0)
	_music_player.pitch_scale = lerpf(_music_player.pitch_scale, target_pitch, delta * 5.0)

func _play_tone(freq_start: float, freq_end: float, duration: float, wave: String = "sine", gain: float = 0.25) -> void:
	var p := _players[_pool_index]
	_pool_index = (_pool_index + 1) % POOL_SIZE
	p.play()
	var playback := p.get_stream_playback() as AudioStreamGeneratorPlayback
	if playback == null:
		return

	var total_samples := int(SAMPLE_RATE * duration)
	var phase := 0.0
	for i in range(total_samples):
		var t := float(i) / float(max(1, total_samples))
		var freq := lerpf(freq_start, freq_end, t)
		var env := (1.0 - t) * (1.0 - t)
		phase += freq / SAMPLE_RATE
		var sample := 0.0
		if wave == "sine":
			sample = sin(phase * TAU)
		elif wave == "triangle":
			sample = 2.0 * absf(2.0 * (phase - floorf(phase + 0.5))) - 1.0
		elif wave == "square":
			sample = 1.0 if fmod(phase, 1.0) < 0.5 else -1.0
		var val := sample * env * gain
		playback.push_frame(Vector2(val, val))

func play_coin() -> void:
	_play_tone(1046.50, 1567.98, 0.13, "sine", 0.22)

func play_jump() -> void:
	_play_tone(260.0, 680.0, 0.18, "triangle", 0.24)

func play_slide() -> void:
	_play_tone(440.0, 140.0, 0.16, "triangle", 0.20)

func play_lane_switch() -> void:
	_play_tone(360.0, 540.0, 0.08, "sine", 0.15)

func play_powerup() -> void:
	_play_tone(440.0, 1174.66, 0.30, "triangle", 0.28)

func play_portal() -> void:
	_play_tone(330.0, 987.77, 0.34, "sine", 0.30)

func play_shield_break() -> void:
	_play_tone(520.0, 110.0, 0.26, "square", 0.22)

func play_crash() -> void:
	_play_tone(150.0, 45.0, 0.32, "square", 0.28)
