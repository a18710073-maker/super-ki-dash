class_name WorldThemes
extends RefCounted

static func get_worlds() -> Array[Dictionary]:
	return [
		{
			"id": "metro_subway",
			"name": "METRO SUBWAY",
			"subtitle": "Classic Rails & City Skyline",
			"music_track": "run1",
			"sky_top": Color(0.14, 0.56, 0.98),
			"sky_horizon": Color(0.68, 0.91, 1.0),
			"fog_color": Color(0.68, 0.90, 0.99),
			"sun_color": Color(1.0, 0.97, 0.88),
			"sun_energy": 1.38,
			"track_base": Color(0.32, 0.34, 0.40),
			"sleeper_color": Color(0.46, 0.28, 0.16),
			"track_trim": Color(1.0, 0.78, 0.12),
			"wall_color": Color(0.86, 0.42, 0.28),
			"rail_color": Color(0.84, 0.89, 0.96),
			"ground_side": Color(0.30, 0.76, 0.38),
			"train_primary": Color(0.14, 0.52, 0.96),
			"train_secondary": Color(0.96, 0.32, 0.22),
			"train_accent": Color(1.0, 0.84, 0.12),
			"barrier_color": Color(0.96, 0.22, 0.22),
			"building_colors": [
				Color(0.98, 0.46, 0.36),
				Color(0.26, 0.74, 0.96),
				Color(0.98, 0.80, 0.26),
				Color(0.46, 0.84, 0.56),
				Color(0.94, 0.54, 0.78)
			],
			"prop_type": "subway_city"
		},
		{
			"id": "turtle_island",
			"name": "TURTLE COAST",
			"subtitle": "Tropical Rails & Dojo Houses",
			"music_track": "run1",
			"sky_top": Color(0.08, 0.62, 0.98),
			"sky_horizon": Color(0.70, 0.95, 1.0),
			"fog_color": Color(0.68, 0.93, 0.98),
			"sun_color": Color(1.0, 0.96, 0.86),
			"sun_energy": 1.42,
			"track_base": Color(0.44, 0.36, 0.28),
			"sleeper_color": Color(0.62, 0.38, 0.18),
			"track_trim": Color(1.0, 0.48, 0.08),
			"wall_color": Color(0.96, 0.86, 0.62),
			"rail_color": Color(0.86, 0.90, 0.96),
			"ground_side": Color(0.16, 0.76, 0.88),
			"train_primary": Color(1.0, 0.42, 0.06),
			"train_secondary": Color(0.14, 0.46, 0.94),
			"train_accent": Color(1.0, 0.88, 0.16),
			"barrier_color": Color(0.96, 0.24, 0.20),
			"building_colors": [
				Color(0.98, 0.38, 0.54),
				Color(0.98, 0.80, 0.24),
				Color(0.24, 0.78, 0.96),
				Color(0.98, 0.56, 0.24)
			],
			"prop_type": "island"
		},
		{
			"id": "emerald_namek",
			"name": "EMERALD PLANET",
			"subtitle": "Mint Skies & Capsule Domes",
			"music_track": "run2",
			"sky_top": Color(0.16, 0.84, 0.62),
			"sky_horizon": Color(0.68, 0.98, 0.82),
			"fog_color": Color(0.64, 0.96, 0.80),
			"sun_color": Color(0.90, 1.0, 0.92),
			"sun_energy": 1.35,
			"track_base": Color(0.20, 0.38, 0.48),
			"sleeper_color": Color(0.14, 0.56, 0.66),
			"track_trim": Color(0.98, 0.84, 0.16),
			"wall_color": Color(0.22, 0.68, 0.78),
			"rail_color": Color(0.45, 0.98, 0.78),
			"ground_side": Color(0.14, 0.64, 0.82),
			"train_primary": Color(0.48, 0.24, 0.90),
			"train_secondary": Color(0.16, 0.76, 0.64),
			"train_accent": Color(0.98, 0.84, 0.18),
			"barrier_color": Color(0.94, 0.26, 0.48),
			"building_colors": [
				Color(0.96, 0.96, 0.98),
				Color(0.86, 0.94, 1.0),
				Color(0.98, 0.88, 0.70),
				Color(0.78, 0.96, 0.90)
			],
			"prop_type": "namek"
		},
		{
			"id": "neon_cyber",
			"name": "NEON TOKYO",
			"subtitle": "Holo-Rails & Cyber Towers",
			"music_track": "run2",
			"sky_top": Color(0.10, 0.08, 0.30),
			"sky_horizon": Color(0.46, 0.18, 0.66),
			"fog_color": Color(0.36, 0.14, 0.54),
			"sun_color": Color(0.94, 0.72, 1.0),
			"sun_energy": 1.25,
			"track_base": Color(0.16, 0.16, 0.28),
			"sleeper_color": Color(0.26, 0.18, 0.46),
			"track_trim": Color(0.0, 0.96, 0.92),
			"wall_color": Color(0.24, 0.18, 0.44),
			"rail_color": Color(1.0, 0.20, 0.70),
			"ground_side": Color(0.16, 0.12, 0.34),
			"train_primary": Color(0.0, 0.76, 0.96),
			"train_secondary": Color(0.96, 0.18, 0.64),
			"train_accent": Color(1.0, 0.92, 0.16),
			"barrier_color": Color(1.0, 0.18, 0.56),
			"building_colors": [
				Color(0.24, 0.22, 0.48),
				Color(0.34, 0.18, 0.56),
				Color(0.18, 0.32, 0.54),
				Color(0.42, 0.20, 0.56)
			],
			"prop_type": "cyber"
		}
	]

static func get_world(index: int) -> Dictionary:
	var worlds := get_worlds()
	return worlds[posmod(index, worlds.size())]
