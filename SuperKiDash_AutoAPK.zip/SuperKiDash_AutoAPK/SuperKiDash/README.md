# Super Ki Dash — Portrait 3D Cartoon Endless Runner with Custom Music (Godot 4)

## What's Included
- **3 Original Subway Surfers-Inspired Electro-Funk / Anime Music Tracks (`assets/audio/`):**
  1. `menu_theme.wav` (*Ki Street Groove*, 124 BPM) — Street-funk synth & bell groove on the menu screen.
  2. `run_theme_1.wav` (*Turbo Rail Sprint*, 136 BPM) — High-energy breakbeat electro-funk with slap-synth bass and brassy anime lead for **Metro Subway** & **Turtle Coast**.
  3. `run_theme_2.wav` (*Super Ki Overdrive*, 140 BPM) — Driving 16th-note synth arpeggio breakbeat for **Emerald Planet** & **Neon Tokyo**.
- **Locked Portrait Mode (`720x1280`):** Configured in `project.godot`, `export_presets.cfg`, `GameManager`, and `Camera3D` (`keep_aspect = KEEP_WIDTH`) so all 3 lanes and roadside buildings frame perfectly on every Android phone and iPhone.
- **1-Click Export Ready (`export_presets.cfg`):**
  - Open **Project → Export → Android** and click **Export Project** to build `builds/android/SuperKiDash.apk` immediately (once Godot Export Templates + JDK 17 + Android SDK are installed).
  - Open **Project → Export → iOS** on macOS and click **Export Project** to generate the Xcode project.
