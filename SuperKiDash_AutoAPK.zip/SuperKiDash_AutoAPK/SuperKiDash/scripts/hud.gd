extends CanvasLayer

var _root_margin: MarginContainer
var _menu_panel: Control
var _hud_panel: Control
var _pause_panel: Control
var _gameover_panel: Control

var _score_label: Label
var _mult_label: Label
var _coin_label: Label
var _world_badge: Label
var _shield_btn: Button
var _music_btn: Button
var _powerup_bar: ProgressBar
var _powerup_label: Label
var _banner_label: Label

var _menu_high_score: Label
var _menu_coins: Label
var _koku_btn: Button
var _vex_btn: Button
var _world_buttons: Array[Button] = []

var _final_score_label: Label
var _final_coins_label: Label
var _new_record_label: Label

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_build_ui()
	_apply_mobile_safe_area()

	GameManager.game_started.connect(_on_game_started)
	GameManager.game_over.connect(_on_game_over)
	GameManager.score_updated.connect(_on_score_updated)
	GameManager.coins_updated.connect(_on_coins_updated)
	GameManager.world_changed.connect(_on_world_changed)
	GameManager.powerup_updated.connect(_on_powerup_updated)
	GameManager.shield_changed.connect(_on_shield_changed)
	GameManager.pause_toggled.connect(_on_pause_toggled)
	GameManager.player_stumbled.connect(_on_player_stumbled)

	_show_menu()

func _apply_mobile_safe_area() -> void:
	var safe := DisplayServer.get_display_safe_area()
	var win_size := DisplayServer.window_get_size()
	if win_size.x > 0 and win_size.y > 0:
		var top_pad := maxi(28, int((float(safe.position.y) / float(win_size.y)) * 1280.0) + 16)
		var bottom_pad := maxi(28, int((float(win_size.y - safe.end.y) / float(win_size.y)) * 1280.0) + 16)
		_root_margin.add_theme_constant_override("margin_top", top_pad)
		_root_margin.add_theme_constant_override("margin_bottom", bottom_pad)

func _make_card_style(bg: Color, border: Color = Color.WHITE, radius: int = 20) -> StyleBoxFlat:
	var sb := StyleBoxFlat.new()
	sb.bg_color = bg
	sb.border_color = border
	sb.set_border_width_all(3)
	sb.set_corner_radius_all(radius)
	sb.content_margin_left = 18
	sb.content_margin_right = 18
	sb.content_margin_top = 12
	sb.content_margin_bottom = 12
	return sb

func _build_ui() -> void:
	_root_margin = MarginContainer.new()
	_root_margin.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root_margin.add_theme_constant_override("margin_left", 24)
	_root_margin.add_theme_constant_override("margin_right", 24)
	_root_margin.add_theme_constant_override("margin_top", 32)
	_root_margin.add_theme_constant_override("margin_bottom", 32)
	add_child(_root_margin)

	# --- 1. TITLE / MENU SCREEN ---
	_menu_panel = VBoxContainer.new()
	_menu_panel.alignment = BoxContainer.ALIGNMENT_CENTER
	_menu_panel.add_theme_constant_override("separation", 14)
	_root_margin.add_child(_menu_panel)

	var title := Label.new()
	title.text = "SUPER KI DASH"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_size_override("font_size", 58)
	title.add_theme_color_override("font_color", Color(1.0, 0.90, 0.14))
	title.add_theme_color_override("font_outline_color", Color(0.10, 0.10, 0.18))
	title.add_theme_constant_override("outline_size", 12)
	_menu_panel.add_child(title)

	var sub := Label.new()
	sub.text = "3D CARTOON ENDLESS RUNNER"
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sub.add_theme_font_size_override("font_size", 19)
	sub.add_theme_color_override("font_color", Color.WHITE)
	sub.add_theme_color_override("font_outline_color", Color(0.10, 0.10, 0.18))
	sub.add_theme_constant_override("outline_size", 6)
	_menu_panel.add_child(sub)

	var stats_box := PanelContainer.new()
	stats_box.add_theme_stylebox_override("panel", _make_card_style(Color(0.08, 0.10, 0.18, 0.78), Color(1.0, 0.84, 0.12), 18))
	_menu_panel.add_child(stats_box)

	var stats_row := HBoxContainer.new()
	stats_row.alignment = BoxContainer.ALIGNMENT_CENTER
	stats_row.add_theme_constant_override("separation", 24)
	stats_box.add_child(stats_row)

	_menu_high_score = Label.new()
	_menu_high_score.add_theme_font_size_override("font_size", 20)
	_menu_high_score.add_theme_color_override("font_color", Color.WHITE)
	stats_row.add_child(_menu_high_score)

	_menu_coins = Label.new()
	_menu_coins.add_theme_font_size_override("font_size", 20)
	_menu_coins.add_theme_color_override("font_color", Color(1.0, 0.86, 0.18))
	stats_row.add_child(_menu_coins)

	_music_btn = Button.new()
	_music_btn.custom_minimum_size = Vector2(118, 42)
	_music_btn.add_theme_font_size_override("font_size", 15)
	_music_btn.add_theme_stylebox_override("normal", _make_card_style(Color(0.18, 0.24, 0.44), Color.WHITE, 12))
	_music_btn.pressed.connect(_on_toggle_music)
	stats_row.add_child(_music_btn)

	var runner_row := HBoxContainer.new()
	runner_row.add_theme_constant_override("separation", 12)
	_menu_panel.add_child(runner_row)

	_koku_btn = Button.new()
	_koku_btn.text = "KOKU
Orange Gi Hero"
	_koku_btn.custom_minimum_size = Vector2(0, 66)
	_koku_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_koku_btn.add_theme_font_size_override("font_size", 17)
	_koku_btn.pressed.connect(func(): _select_runner("koku"))
	runner_row.add_child(_koku_btn)

	_vex_btn = Button.new()
	_vex_btn.text = "VEX
Battle Armor Rival"
	_vex_btn.custom_minimum_size = Vector2(0, 66)
	_vex_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_vex_btn.add_theme_font_size_override("font_size", 17)
	_vex_btn.pressed.connect(func(): _select_runner("vex"))
	runner_row.add_child(_vex_btn)

	var world_header := Label.new()
	world_header.text = "SELECT STARTING WORLD"
	world_header.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	world_header.add_theme_font_size_override("font_size", 17)
	world_header.add_theme_color_override("font_color", Color.WHITE)
	world_header.add_theme_color_override("font_outline_color", Color(0.1, 0.1, 0.18))
	world_header.add_theme_constant_override("outline_size", 5)
	_menu_panel.add_child(world_header)

	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 10)
	_menu_panel.add_child(grid)

	var worlds := WorldThemes.get_worlds()
	for i in range(worlds.size()):
		var w := worlds[i]
		var btn := Button.new()
		btn.text = "%s
%s" % [w["name"], w["subtitle"]]
		btn.custom_minimum_size = Vector2(0, 68)
		btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		btn.add_theme_font_size_override("font_size", 15)
		btn.pressed.connect(func(): _select_world(i))
		grid.add_child(btn)
		_world_buttons.append(btn)

	var play_btn := Button.new()
	play_btn.text = "TAP TO DASH!"
	play_btn.custom_minimum_size = Vector2(0, 78)
	play_btn.add_theme_font_size_override("font_size", 30)
	play_btn.add_theme_stylebox_override("normal", _make_card_style(Color(1.0, 0.44, 0.06), Color.WHITE, 26))
	play_btn.add_theme_stylebox_override("pressed", _make_card_style(Color(0.86, 0.34, 0.02), Color.WHITE, 26))
	play_btn.pressed.connect(func(): GameManager.start_new_run())
	_menu_panel.add_child(play_btn)

	var controls_hint := Label.new()
	controls_hint.text = "Swipe Left/Right: Lanes  |  Up: Jump  |  Down: Slide  |  Double-Tap: Nimbus Cloud"
	controls_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	controls_hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	controls_hint.add_theme_font_size_override("font_size", 14)
	controls_hint.add_theme_color_override("font_color", Color.WHITE)
	controls_hint.add_theme_color_override("font_outline_color", Color(0.1, 0.1, 0.18))
	controls_hint.add_theme_constant_override("outline_size", 4)
	_menu_panel.add_child(controls_hint)

	# --- 2. IN-GAME RUN HUD ---
	_hud_panel = Control.new()
	_hud_panel.set_anchors_preset(Control.PRESET_FULL_RECT)
	_hud_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root_margin.add_child(_hud_panel)

	var top_bar := HBoxContainer.new()
	top_bar.set_anchors_preset(Control.PRESET_TOP_WIDE)
	top_bar.add_theme_constant_override("separation", 12)
	_hud_panel.add_child(top_bar)

	var pause_btn := Button.new()
	pause_btn.text = "II"
	pause_btn.custom_minimum_size = Vector2(58, 58)
	pause_btn.add_theme_font_size_override("font_size", 22)
	pause_btn.add_theme_stylebox_override("normal", _make_card_style(Color(0.10, 0.12, 0.22, 0.82), Color.WHITE, 16))
	pause_btn.pressed.connect(func(): GameManager.toggle_pause())
	top_bar.add_child(pause_btn)

	_world_badge = Label.new()
	_world_badge.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_world_badge.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_world_badge.add_theme_font_size_override("font_size", 18)
	_world_badge.add_theme_color_override("font_color", Color.WHITE)
	_world_badge.add_theme_color_override("font_outline_color", Color(0.1, 0.1, 0.18))
	_world_badge.add_theme_constant_override("outline_size", 5)
	top_bar.add_child(_world_badge)

	var score_vbox := VBoxContainer.new()
	score_vbox.alignment = BoxContainer.ALIGNMENT_END
	top_bar.add_child(score_vbox)

	_score_label = Label.new()
	_score_label.text = "000000"
	_score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	_score_label.add_theme_font_size_override("font_size", 30)
	_score_label.add_theme_color_override("font_color", Color.WHITE)
	_score_label.add_theme_color_override("font_outline_color", Color(0.1, 0.1, 0.18))
	_score_label.add_theme_constant_override("outline_size", 6)
	score_vbox.add_child(_score_label)

	var sub_row := HBoxContainer.new()
	sub_row.alignment = BoxContainer.ALIGNMENT_END
	sub_row.add_theme_constant_override("separation", 12)
	score_vbox.add_child(sub_row)

	_mult_label = Label.new()
	_mult_label.text = "1x"
	_mult_label.add_theme_font_size_override("font_size", 18)
	_mult_label.add_theme_color_override("font_color", Color(0.35, 0.96, 1.0))
	_mult_label.add_theme_color_override("font_outline_color", Color(0.1, 0.1, 0.18))
	_mult_label.add_theme_constant_override("outline_size", 4)
	sub_row.add_child(_mult_label)

	_coin_label = Label.new()
	_coin_label.text = "KI ORBS: 0"
	_coin_label.add_theme_font_size_override("font_size", 18)
	_coin_label.add_theme_color_override("font_color", Color(1.0, 0.86, 0.14))
	_coin_label.add_theme_color_override("font_outline_color", Color(0.1, 0.1, 0.18))
	_coin_label.add_theme_constant_override("outline_size", 4)
	sub_row.add_child(_coin_label)

	_banner_label = Label.new()
	_banner_label.set_anchors_preset(Control.PRESET_CENTER_TOP)
	_banner_label.position = Vector2(-220, 140)
	_banner_label.custom_minimum_size = Vector2(440, 60)
	_banner_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_banner_label.add_theme_font_size_override("font_size", 32)
	_banner_label.add_theme_color_override("font_color", Color(1.0, 0.92, 0.22))
	_banner_label.add_theme_color_override("font_outline_color", Color(0.1, 0.1, 0.18))
	_banner_label.add_theme_constant_override("outline_size", 8)
	_banner_label.visible = false
	_hud_panel.add_child(_banner_label)

	var bottom_bar := HBoxContainer.new()
	bottom_bar.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
	bottom_bar.add_theme_constant_override("separation", 16)
	_hud_panel.add_child(bottom_bar)

	_shield_btn = Button.new()
	_shield_btn.text = "NIMBUS (2)"
	_shield_btn.custom_minimum_size = Vector2(160, 62)
	_shield_btn.add_theme_font_size_override("font_size", 18)
	_shield_btn.add_theme_stylebox_override("normal", _make_card_style(Color(0.96, 0.68, 0.08, 0.95), Color.WHITE, 18))
	_shield_btn.pressed.connect(func(): GameManager.try_activate_hoverboard())
	bottom_bar.add_child(_shield_btn)

	var p_vbox := VBoxContainer.new()
	p_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	p_vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	bottom_bar.add_child(p_vbox)

	_powerup_label = Label.new()
	_powerup_label.text = ""
	_powerup_label.add_theme_font_size_override("font_size", 16)
	_powerup_label.add_theme_color_override("font_color", Color.WHITE)
	p_vbox.add_child(_powerup_label)

	_powerup_bar = ProgressBar.new()
	_powerup_bar.custom_minimum_size = Vector2(0, 18)
	_powerup_bar.show_percentage = false
	_powerup_bar.visible = false
	p_vbox.add_child(_powerup_bar)

	# --- 3. PAUSE PANEL ---
	_pause_panel = VBoxContainer.new()
	_pause_panel.alignment = BoxContainer.ALIGNMENT_CENTER
	_pause_panel.add_theme_constant_override("separation", 18)
	_root_margin.add_child(_pause_panel)

	var pause_title := Label.new()
	pause_title.text = "PAUSED"
	pause_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	pause_title.add_theme_font_size_override("font_size", 48)
	pause_title.add_theme_color_override("font_color", Color.WHITE)
	_pause_panel.add_child(pause_title)

	var resume_btn := Button.new()
	resume_btn.text = "RESUME"
	resume_btn.custom_minimum_size = Vector2(0, 72)
	resume_btn.add_theme_font_size_override("font_size", 26)
	resume_btn.add_theme_stylebox_override("normal", _make_card_style(Color(0.14, 0.82, 0.34), Color.WHITE, 20))
	resume_btn.pressed.connect(func(): GameManager.toggle_pause())
	_pause_panel.add_child(resume_btn)

	var mute_pause_btn := Button.new()
	mute_pause_btn.text = "TOGGLE MUSIC"
	mute_pause_btn.custom_minimum_size = Vector2(0, 64)
	mute_pause_btn.add_theme_font_size_override("font_size", 22)
	mute_pause_btn.add_theme_stylebox_override("normal", _make_card_style(Color(0.20, 0.48, 0.92), Color.WHITE, 20))
	mute_pause_btn.pressed.connect(_on_toggle_music)
	_pause_panel.add_child(mute_pause_btn)

	var quit_btn := Button.new()
	quit_btn.text = "WORLD MENU"
	quit_btn.custom_minimum_size = Vector2(0, 64)
	quit_btn.add_theme_font_size_override("font_size", 22)
	quit_btn.add_theme_stylebox_override("normal", _make_card_style(Color(0.88, 0.26, 0.24), Color.WHITE, 20))
	quit_btn.pressed.connect(_return_to_menu)
	_pause_panel.add_child(quit_btn)

	# --- 4. GAME OVER PANEL ---
	_gameover_panel = VBoxContainer.new()
	_gameover_panel.alignment = BoxContainer.ALIGNMENT_CENTER
	_gameover_panel.add_theme_constant_override("separation", 18)
	_root_margin.add_child(_gameover_panel)

	var go_title := Label.new()
	go_title.text = "RING OUT!"
	go_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	go_title.add_theme_font_size_override("font_size", 54)
	go_title.add_theme_color_override("font_color", Color(1.0, 0.28, 0.24))
	go_title.add_theme_color_override("font_outline_color", Color(0.1, 0.1, 0.18))
	go_title.add_theme_constant_override("outline_size", 10)
	_gameover_panel.add_child(go_title)

	_new_record_label = Label.new()
	_new_record_label.text = "NEW POWER LEVEL RECORD!"
	_new_record_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_new_record_label.add_theme_font_size_override("font_size", 24)
	_new_record_label.add_theme_color_override("font_color", Color(1.0, 0.88, 0.14))
	_new_record_label.visible = false
	_gameover_panel.add_child(_new_record_label)

	var summary_card := PanelContainer.new()
	summary_card.add_theme_stylebox_override("panel", _make_card_style(Color(0.08, 0.10, 0.18, 0.88), Color.WHITE, 22))
	_gameover_panel.add_child(summary_card)

	var sum_vbox := VBoxContainer.new()
	sum_vbox.add_theme_constant_override("separation", 10)
	summary_card.add_child(sum_vbox)

	_final_score_label = Label.new()
	_final_score_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_final_score_label.add_theme_font_size_override("font_size", 32)
	sum_vbox.add_child(_final_score_label)

	_final_coins_label = Label.new()
	_final_coins_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_final_coins_label.add_theme_font_size_override("font_size", 24)
	_final_coins_label.add_theme_color_override("font_color", Color(1.0, 0.86, 0.18))
	sum_vbox.add_child(_final_coins_label)

	var replay_btn := Button.new()
	replay_btn.text = "RUN AGAIN"
	replay_btn.custom_minimum_size = Vector2(0, 78)
	replay_btn.add_theme_font_size_override("font_size", 28)
	replay_btn.add_theme_stylebox_override("normal", _make_card_style(Color(1.0, 0.44, 0.06), Color.WHITE, 22))
	replay_btn.pressed.connect(func(): GameManager.start_new_run())
	_gameover_panel.add_child(replay_btn)

	var menu_btn := Button.new()
	menu_btn.text = "CHANGE RUNNER / WORLD"
	menu_btn.custom_minimum_size = Vector2(0, 62)
	menu_btn.add_theme_font_size_override("font_size", 21)
	menu_btn.add_theme_stylebox_override("normal", _make_card_style(Color(0.20, 0.48, 0.92), Color.WHITE, 20))
	menu_btn.pressed.connect(_return_to_menu)
	_gameover_panel.add_child(menu_btn)

func _on_toggle_music() -> void:
	SoundManager.toggle_music_mute()
	GameManager.save_data()
	_refresh_music_button()

func _refresh_music_button() -> void:
	_music_btn.text = "BGM: OFF" if SoundManager.music_muted else "BGM: ON"

func _select_runner(runner_id: String) -> void:
	GameManager.set_runner(runner_id)
	_refresh_runner_buttons()

func _refresh_runner_buttons() -> void:
	var is_koku := (GameManager.selected_runner == "koku")
	_koku_btn.add_theme_stylebox_override(
		"normal",
		_make_card_style(
			Color(1.0, 0.42, 0.06) if is_koku else Color(0.12, 0.14, 0.24, 0.82),
			Color(1.0, 0.90, 0.14) if is_koku else Color(0.6, 0.65, 0.75, 0.5),
			16
		)
	)
	_vex_btn.add_theme_stylebox_override(
		"normal",
		_make_card_style(
			Color(0.14, 0.36, 0.88) if not is_koku else Color(0.12, 0.14, 0.24, 0.82),
			Color(1.0, 0.90, 0.14) if not is_koku else Color(0.6, 0.65, 0.75, 0.5),
			16
		)
	)

func _select_world(index: int) -> void:
	GameManager.set_preview_world(index)
	_refresh_world_buttons()

func _refresh_world_buttons() -> void:
	var worlds := WorldThemes.get_worlds()
	for i in range(_world_buttons.size()):
		var w := worlds[i]
		var is_sel := (i == GameManager.selected_start_world)
		var bg: Color = w["train_primary"] if is_sel else Color(0.12, 0.14, 0.24, 0.82)
		var border := Color(1.0, 0.90, 0.14) if is_sel else Color(0.6, 0.65, 0.75, 0.5)
		_world_buttons[i].add_theme_stylebox_override("normal", _make_card_style(bg, border, 16))

func _show_menu() -> void:
	_menu_panel.visible = true
	_hud_panel.visible = false
	_pause_panel.visible = false
	_gameover_panel.visible = false
	_menu_high_score.text = "BEST: %d" % GameManager.high_score
	_menu_coins.text = "ORBS: %d" % GameManager.total_coins
	_refresh_music_button()
	_refresh_runner_buttons()
	_refresh_world_buttons()
	SoundManager.play_music("menu")

func _return_to_menu() -> void:
	get_tree().paused = false
	GameManager.state = GameManager.GameState.MENU
	_show_menu()

func _on_game_started() -> void:
	_menu_panel.visible = false
	_hud_panel.visible = true
	_pause_panel.visible = false
	_gameover_panel.visible = false
	_powerup_bar.visible = false
	_powerup_label.text = ""

func _on_score_updated(score: int, mult: int) -> void:
	_score_label.text = "%06d" % score
	_mult_label.text = "%dx" % mult

func _on_coins_updated(run_coins: int, _total: int) -> void:
	_coin_label.text = "KI ORBS: %d" % run_coins

func _on_world_changed(_idx: int, world_data: Dictionary) -> void:
	_world_badge.text = world_data["name"]
	if GameManager.state == GameManager.GameState.PLAYING:
		_show_banner("ENTERING %s!" % world_data["name"])

func _on_player_stumbled() -> void:
	_show_banner("WATCH OUT! GUARD CHASING!")

func _show_banner(msg: String) -> void:
	_banner_label.text = msg
	_banner_label.visible = true
	var tw := create_tween()
	tw.tween_interval(2.0)
	tw.tween_callback(func(): _banner_label.visible = false)

func _on_powerup_updated(pname: String, time_left: float, duration: float) -> void:
	if time_left > 0.0:
		_powerup_bar.visible = true
		_powerup_bar.max_value = duration
		_powerup_bar.value = time_left
		_powerup_label.text = "%s: %.1fs" % [pname, time_left]
	else:
		_powerup_bar.visible = false
		_powerup_label.text = ""

func _on_shield_changed(active: bool, charges: int) -> void:
	if active:
		_shield_btn.text = "SUPER AURA!"
	else:
		_shield_btn.text = "NIMBUS (%d)" % charges

func _on_pause_toggled(is_paused: bool) -> void:
	_pause_panel.visible = is_paused

func _on_game_over(final_score: int, coins_earned: int, is_new_record: bool) -> void:
	_hud_panel.visible = false
	_gameover_panel.visible = true
	_final_score_label.text = "POWER SCORE: %d" % final_score
	_final_coins_label.text = "+%d KI ORBS COLLECTED" % coins_earned
	_new_record_label.visible = is_new_record
