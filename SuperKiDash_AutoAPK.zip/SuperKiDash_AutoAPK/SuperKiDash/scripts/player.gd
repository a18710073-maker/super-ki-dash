extends CharacterBody3D

signal crashed
signal stumbled
signal world_portal_entered

const LANE_LERP_SPEED := 16.5
const GRAVITY := 48.0
const BASE_JUMP_VELOCITY := 16.5
const SUPER_JUMP_VELOCITY := 22.4
const FAST_FALL_VELOCITY := -34.0
const SLIDE_DURATION := 0.72
const MIN_SWIPE_DISTANCE := 42.0

var current_lane: int = 1
var prev_lane: int = 1
var is_sliding: bool = false
var slide_timer: float = 0.0
var run_cycle: float = 0.0
var invuln_timer: float = 0.0

var _touch_active: bool = false
var _touch_start: Vector2 = Vector2.ZERO
var _swipe_consumed: bool = false
var _last_tap_time: float = 0.0

var _rig: Dictionary = {}
var _chaser_rig: Dictionary = {}
var _chaser_node: Node3D
var _dust_particles: CPUParticles3D
var _pickup_particles: CPUParticles3D
var _hitbox_area: Area3D
var _hitbox_shape: BoxShape3D

func _ready() -> void:
	_rebuild_character_visual(GameManager.selected_runner)
	_build_chaser()
	_build_particles()

	_hitbox_area = Area3D.new()
	_hitbox_area.name = "PlayerSensor"
	add_child(_hitbox_area)

	var col := CollisionShape3D.new()
	_hitbox_shape = BoxShape3D.new()
	_hitbox_shape.size = Vector3(0.75, 1.65, 0.75)
	col.shape = _hitbox_shape
	col.position = Vector3(0, 0.85, 0)
	_hitbox_area.add_child(col)

	_hitbox_area.area_entered.connect(_on_area_entered)
	GameManager.game_started.connect(_on_game_started)
	GameManager.shield_changed.connect(_on_shield_changed)
	GameManager.runner_changed.connect(_rebuild_character_visual)

func _rebuild_character_visual(runner_id: String) -> void:
	if _rig.has("root") and is_instance_valid(_rig["root"]):
		_rig["root"].queue_free()
	_rig = CartoonFactory.build_character_rig(runner_id)
	add_child(_rig["root"])

func _build_chaser() -> void:
	_chaser_node = Node3D.new()
	_chaser_node.position = Vector3(0, 0, 2.2)
	add_child(_chaser_node)
	_chaser_rig = CartoonFactory.build_character_rig("chaser")
	_chaser_node.add_child(_chaser_rig["root"])

func _build_particles() -> void:
	_dust_particles = CPUParticles3D.new()
	_dust_particles.position = Vector3(0, 0.12, 0.3)
	_dust_particles.amount = 14
	_dust_particles.lifetime = 0.35
	_dust_particles.direction = Vector3(0, 0.4, 1.0)
	_dust_particles.spread = 28.0
	_dust_particles.initial_velocity_min = 2.0
	_dust_particles.initial_velocity_max = 4.2
	_dust_particles.gravity = Vector3(0, 2.0, 0)
	_dust_particles.scale_amount_min = 0.22
	_dust_particles.scale_amount_max = 0.42
	var puff := SphereMesh.new()
	puff.radius = 0.35
	puff.height = 0.7
	puff.radial_segments = 8
	puff.rings = 6
	puff.material = CartoonFactory.make_toon_material(Color(0.96, 0.96, 0.98), 0.1, 0.0)
	_dust_particles.mesh = puff
	add_child(_dust_particles)

	_pickup_particles = CPUParticles3D.new()
	_pickup_particles.position = Vector3(0, 1.0, 0)
	_pickup_particles.one_shot = true
	_pickup_particles.explosiveness = 0.9
	_pickup_particles.amount = 12
	_pickup_particles.lifetime = 0.35
	_pickup_particles.direction = Vector3(0, 1.0, 0)
	_pickup_particles.spread = 180.0
	_pickup_particles.initial_velocity_min = 3.5
	_pickup_particles.initial_velocity_max = 6.5
	_pickup_particles.gravity = Vector3(0, -8.0, 0)
	_pickup_particles.emitting = false
	var star := BoxMesh.new()
	star.size = Vector3(0.22, 0.22, 0.22)
	star.material = CartoonFactory.make_toon_material(Color(1.0, 0.92, 0.16), 0.95, 0.0)
	_pickup_particles.mesh = star
	add_child(_pickup_particles)

func _on_game_started() -> void:
	current_lane = 1
	prev_lane = 1
	position = Vector3(0.0, 0.0, 0.0)
	velocity = Vector3.ZERO
	is_sliding = false
	slide_timer = 0.0
	invuln_timer = 0.0
	_set_standing_hitbox()
	_rig["hoverboard"].visible = false
	_rig["aura"].visible = false

func _on_shield_changed(active: bool, _charges: int) -> void:
	_rig["hoverboard"].visible = active

func _input(event: InputEvent) -> void:
	if GameManager.state != GameManager.GameState.PLAYING:
		return

	if event.is_action_pressed("move_left"):
		_change_lane(-1)
	elif event.is_action_pressed("move_right"):
		_change_lane(1)
	elif event.is_action_pressed("jump"):
		_try_jump()
	elif event.is_action_pressed("slide"):
		_try_slide()
	elif event.is_action_pressed("hoverboard"):
		GameManager.try_activate_hoverboard()

	if event is InputEventScreenTouch:
		if event.pressed:
			_touch_active = true
			_touch_start = event.position
			_swipe_consumed = false
			var now := Time.get_ticks_msec() / 1000.0
			if now - _last_tap_time < 0.26:
				GameManager.try_activate_hoverboard()
			_last_tap_time = now
		else:
			_touch_active = false
	elif event is InputEventScreenDrag and _touch_active and not _swipe_consumed:
		var delta_vec: Vector2 = event.position - _touch_start
		if delta_vec.length() >= MIN_SWIPE_DISTANCE:
			_swipe_consumed = true
			if absf(delta_vec.x) > absf(delta_vec.y):
				_change_lane(1 if delta_vec.x > 0.0 else -1)
			else:
				if delta_vec.y < 0.0:
					_try_jump()
				else:
					_try_slide()

func _physics_process(delta: float) -> void:
	if not _rig.has("root"):
		return

	var super_on := GameManager.is_super_mode_active() and GameManager.state == GameManager.GameState.PLAYING
	var hair_mat: ShaderMaterial = _rig["hair_mat"]
	var aura: Node3D = _rig["aura"]
	aura.visible = super_on
	if super_on:
		hair_mat.set_shader_parameter("albedo_color", Color(1.0, 0.92, 0.14))
		hair_mat.set_shader_parameter("emission_color", Color(1.0, 0.85, 0.10))
		hair_mat.set_shader_parameter("emission_energy", 0.85)
		aura.rotation.y += delta * 6.5
		aura.scale = Vector3.ONE * (1.0 + sin(Time.get_ticks_msec() * 0.02) * 0.08)
	else:
		hair_mat.set_shader_parameter("albedo_color", Color(0.08, 0.08, 0.12))
		hair_mat.set_shader_parameter("emission_energy", 0.0)

	if GameManager.state == GameManager.GameState.MENU:
		_chaser_node.visible = false
		_dust_particles.emitting = false
		run_cycle += delta * 4.5
		_rig["torso"].position.y = 1.05 + sin(run_cycle) * 0.04
		_rig["left_arm"].rotation.x = sin(run_cycle) * 0.2
		_rig["right_arm"].rotation.x = -sin(run_cycle) * 0.2
		return

	if GameManager.state != GameManager.GameState.PLAYING:
		_dust_particles.emitting = false
		return

	if invuln_timer > 0.0:
		invuln_timer -= delta
		_rig["root"].visible = fmod(invuln_timer * 18.0, 1.0) > 0.35
	else:
		_rig["root"].visible = true

	var target_x: float = GameManager.LANES[current_lane]
	var prev_x := position.x
	position.x = lerpf(position.x, target_x, clampf(LANE_LERP_SPEED * delta, 0.0, 1.0))
	var lateral_vel := (position.x - prev_x) / maxf(0.001, delta)

	if GameManager.jetpack_timer > 0.0:
		position.y = lerpf(position.y, 6.2, delta * 6.0)
		velocity.y = 0.0
		is_sliding = false
	else:
		if not is_on_floor():
			velocity.y -= GRAVITY * delta
		move_and_slide()

	_dust_particles.emitting = is_on_floor() and GameManager.jetpack_timer <= 0.0

	if is_sliding:
		slide_timer -= delta
		if slide_timer <= 0.0:
			is_sliding = false
			_set_standing_hitbox()

	_animate_character(delta, lateral_vel)
	_animate_chaser(delta)

func _change_lane(dir: int) -> void:
	var new_lane := clampi(current_lane + dir, 0, 2)
	if new_lane != current_lane:
		prev_lane = current_lane
		current_lane = new_lane
		SoundManager.play_lane_switch()

func _try_jump() -> void:
	if GameManager.jetpack_timer > 0.0:
		return
	if is_on_floor():
		is_sliding = false
		_set_standing_hitbox()
		var jump_power := SUPER_JUMP_VELOCITY if GameManager.sneakers_timer > 0.0 else BASE_JUMP_VELOCITY
		velocity.y = jump_power
		SoundManager.play_jump()

func _try_slide() -> void:
	if GameManager.jetpack_timer > 0.0:
		return
	if not is_on_floor():
		velocity.y = FAST_FALL_VELOCITY
	is_sliding = true
	slide_timer = SLIDE_DURATION
	_set_sliding_hitbox()
	SoundManager.play_slide()

func _set_standing_hitbox() -> void:
	_hitbox_shape.size = Vector3(0.75, 1.65, 0.75)
	_hitbox_area.get_child(0).position = Vector3(0, 0.85, 0)

func _set_sliding_hitbox() -> void:
	_hitbox_shape.size = Vector3(0.75, 0.72, 0.85)
	_hitbox_area.get_child(0).position = Vector3(0, 0.38, 0)

func _animate_character(delta: float, lateral_vel: float) -> void:
	var visual: Node3D = _rig["root"]
	var torso: Node3D = _rig["torso"]
	var left_arm: Node3D = _rig["left_arm"]
	var right_arm: Node3D = _rig["right_arm"]
	var left_leg: Node3D = _rig["left_leg"]
	var right_leg: Node3D = _rig["right_leg"]

	visual.rotation.z = lerpf(visual.rotation.z, clampf(-lateral_vel * 0.025, -0.38, 0.38), delta * 14.0)

	if GameManager.jetpack_timer > 0.0:
		visual.rotation.x = lerpf(visual.rotation.x, -1.05, delta * 10.0)
		left_arm.rotation.x = -2.85
		right_arm.rotation.x = 0.25
		left_leg.rotation.x = 0.18
		right_leg.rotation.x = -0.15
		return

	if is_sliding:
		visual.scale.y = lerpf(visual.scale.y, 0.52, delta * 18.0)
		visual.rotation.x = lerpf(visual.rotation.x, 0.65, delta * 16.0)
		return
	else:
		visual.scale.y = lerpf(visual.scale.y, 1.0, delta * 16.0)
		visual.rotation.x = lerpf(visual.rotation.x, -0.12, delta * 14.0)

	if not is_on_floor():
		left_arm.rotation.x = -1.35
		right_arm.rotation.x = 0.85
		left_leg.rotation.x = 0.95
		right_leg.rotation.x = -0.65
		return

	var stride_speed := GameManager.current_speed * 0.68
	run_cycle += delta * stride_speed
	var swing := sin(run_cycle)
	torso.position.y = 1.05 + absf(cos(run_cycle)) * 0.09
	left_leg.rotation.x = swing * 1.08
	right_leg.rotation.x = -swing * 1.08
	left_arm.rotation.x = -swing * 0.95
	right_arm.rotation.x = swing * 0.95

func _animate_chaser(delta: float) -> void:
	if GameManager.chaser_danger_timer <= 0.0 or GameManager.jetpack_timer > 0.0:
		_chaser_node.visible = false
		return
	_chaser_node.visible = true
	var z_offset := lerpf(4.8, 1.85, clampf(GameManager.chaser_danger_timer / 4.5, 0.0, 1.0))
	_chaser_node.position = Vector3(0.0, -position.y * 0.85, z_offset)
	var swing := sin(run_cycle * 1.1)
	_chaser_rig["left_leg"].rotation.x = swing * 1.05
	_chaser_rig["right_leg"].rotation.x = -swing * 1.05
	_chaser_rig["left_arm"].rotation.x = -swing * 0.95
	_chaser_rig["right_arm"].rotation.x = swing * 0.95

func _on_area_entered(area: Area3D) -> void:
	if GameManager.state != GameManager.GameState.PLAYING:
		return

	var kind: String = area.get_meta("kind", "")
	match kind:
		"coin":
			GameManager.add_coin(1)
			_pickup_particles.restart()
			_pickup_particles.emitting = true
			area.queue_free()
		"powerup":
			var ptype: String = area.get_meta("powerup_type", "magnet")
			GameManager.activate_powerup(ptype)
			_pickup_particles.restart()
			_pickup_particles.emitting = true
			area.queue_free()
		"portal":
			if not area.get_meta("triggered", false):
				area.set_meta("triggered", true)
				GameManager.advance_to_next_world()
				world_portal_entered.emit()
		"obstacle":
			if invuln_timer > 0.0 or GameManager.jetpack_timer > 0.0:
				return
			var obs_type: String = area.get_meta("obs_type", "barrier")
			if obs_type == "train" and position.y >= 2.25:
				return
			if obs_type == "high_gate" and is_sliding:
				return
			if obs_type == "low_barrier" and position.y >= 1.05:
				return
			if obs_type == "combo_barrier" and (is_sliding or position.y >= 1.25):
				return

			var target_x: float = GameManager.LANES[current_lane]
			if obs_type == "train" and absf(position.x - target_x) > 0.55 and current_lane != prev_lane:
				current_lane = prev_lane
				if GameManager.register_side_stumble():
					invuln_timer = 0.65
					stumbled.emit()
					return

			if GameManager.consume_hoverboard_shield():
				invuln_timer = 1.4
				_pickup_particles.restart()
				_pickup_particles.emitting = true
				area.queue_free()
				crashed.emit()
			else:
				crashed.emit()
				GameManager.trigger_game_over()
