extends Node3D

@export var player_path: NodePath
@export var world_env_path: NodePath
@export var sun_light_path: NodePath

var _player: Node3D
var _camera: Camera3D
var _world_env: WorldEnvironment
var _sun: DirectionalLight3D

var _shake_strength: float = 0.0
var _target_sky_top: Color
var _target_sky_horizon: Color
var _target_fog: Color
var _target_sun: Color

func _ready() -> void:
	_camera = get_node("Camera3D")
	if player_path != NodePath():
		_player = get_node(player_path)
		if _player.has_signal("crashed"):
			_player.crashed.connect(_on_crashed)
		if _player.has_signal("stumbled"):
			_player.stumbled.connect(_on_stumbled)
	if world_env_path != NodePath():
		_world_env = get_node(world_env_path)
	if sun_light_path != NodePath():
		_sun = get_node(sun_light_path)

	GameManager.world_changed.connect(_on_world_changed)
	_apply_world_colors(WorldThemes.get_world(GameManager.current_world_index), true)

func _on_crashed() -> void:
	_shake_strength = 0.45

func _on_stumbled() -> void:
	_shake_strength = 0.24

func _on_world_changed(_idx: int, world_data: Dictionary) -> void:
	_apply_world_colors(world_data, false)

func _apply_world_colors(w: Dictionary, instant: bool) -> void:
	_target_sky_top = w["sky_top"]
	_target_sky_horizon = w["sky_horizon"]
	_target_fog = w["fog_color"]
	_target_sun = w["sun_color"]

	if _sun != null:
		_sun.light_energy = w["sun_energy"]

	if instant and _world_env != null and _world_env.environment != null:
		var env := _world_env.environment
		env.fog_light_color = _target_fog
		if env.sky != null and env.sky.sky_material is ProceduralSkyMaterial:
			var sky_mat := env.sky.sky_material as ProceduralSkyMaterial
			sky_mat.sky_top_color = _target_sky_top
			sky_mat.sky_horizon_color = _target_sky_horizon
			sky_mat.ground_horizon_color = _target_sky_horizon

func _process(delta: float) -> void:
	var curve_x := sin(GameManager.distance_traveled * 0.0032) * 0.00055
	CartoonFactory.set_world_curve(curve_x, 0.00145)

	if _world_env != null and _world_env.environment != null:
		var env := _world_env.environment
		env.fog_light_color = env.fog_light_color.lerp(_target_fog, delta * 2.5)
		if env.sky != null and env.sky.sky_material is ProceduralSkyMaterial:
			var sky_mat := env.sky.sky_material as ProceduralSkyMaterial
			sky_mat.sky_top_color = sky_mat.sky_top_color.lerp(_target_sky_top, delta * 2.5)
			sky_mat.sky_horizon_color = sky_mat.sky_horizon_color.lerp(_target_sky_horizon, delta * 2.5)
			sky_mat.ground_horizon_color = sky_mat.sky_horizon_color
	if _sun != null:
		_sun.light_color = _sun.light_color.lerp(_target_sun, delta * 2.5)

	if _player != null:
		var target_pos := Vector3(_player.position.x * 0.55, 4.4 + (_player.position.y * 0.55), 6.4)
		if GameManager.state == GameManager.GameState.MENU:
			target_pos = Vector3(1.5, 2.5, 4.2)
		position = position.lerp(target_pos, delta * 7.5)

		var look_target := Vector3(_player.position.x * 0.35, 1.6 + (_player.position.y * 0.45), -7.0)
		if GameManager.state == GameManager.GameState.MENU:
			look_target = Vector3(0.0, 1.3, 0.0)
		_camera.look_at(look_target, Vector3.UP)

	var target_fov := 76.0 if GameManager.is_super_mode_active() else 68.0
	_camera.fov = lerpf(_camera.fov, target_fov, delta * 5.0)

	if _shake_strength > 0.0:
		_shake_strength = maxf(0.0, _shake_strength - delta * 1.8)
		_camera.h_offset = randf_range(-_shake_strength, _shake_strength)
		_camera.v_offset = randf_range(-_shake_strength, _shake_strength)
	else:
		_camera.h_offset = 0.0
		_camera.v_offset = 0.0
