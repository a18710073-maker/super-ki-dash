extends Node

signal game_started
signal game_over(final_score: int, coins_earned: int, is_new_record: bool)
signal score_updated(score: int, multiplier: int)
signal coins_updated(run_coins: int, total_coins: int)
signal world_changed(world_index: int, world_data: Dictionary)
signal runner_changed(runner_id: String)
signal powerup_updated(powerup_name: String, time_left: float, duration: float)
signal shield_changed(active: bool, charges: int)
signal pause_toggled(is_paused: bool)
signal player_stumbled

enum GameState { MENU, PLAYING, PAUSED, GAMEOVER }

const LANE_WIDTH: float = 2.6
const LANES: Array[float] = [-2.6, 0.0, 2.6]
const BASE_RUN_SPEED: float = 22.5
const MAX_RUN_SPEED: float = 45.0
const WORLD_SWITCH_DISTANCE: float = 450.0

var state: GameState = GameState.MENU
var current_speed: float = BASE_RUN_SPEED
var distance_traveled: float = 0.0
var score: int = 0
var high_score: int = 0
var run_coins: int = 0
var total_coins: int = 0

var selected_runner: String = "koku"
var selected_start_world: int = 0
var current_world_index: int = 0
var next_world_distance: float = WORLD_SWITCH_DISTANCE
var world_tour_enabled: bool = true

var chaser_danger_timer: float = 0.0

var magnet_timer: float = 0.0
var magnet_duration: float = 10.0

var jetpack_timer: float = 0.0
var jetpack_duration: float = 6.5

var double_score_timer: float = 0.0
var double_score_duration: float = 10.0

var sneakers_timer: float = 0.0
var sneakers_duration: float = 10.0

var hoverboard_charges: int = 2
var hoverboard_active: bool = false
var hoverboard_timer: float = 0.0
const HOVERBOARD_DURATION: float = 12.0

const SAVE_PATH := "user://super_ki_dash_save.cfg"

func _ready() -> void:
	Engine.max_fps = 60
	# Enforce Portrait Orientation on Android & iPhone at runtime
	DisplayServer.screen_set_orientation(DisplayServer.SCREEN_PORTRAIT)
	load_save_data()

func _process(delta: float) -> void:
	if state != GameState.PLAYING:
		return

	var speed_boost := 1.38 if jetpack_timer > 0.0 else 1.0
	current_speed = min(MAX_RUN_SPEED, BASE_RUN_SPEED + (distance_traveled * 0.0085)) * speed_boost

	distance_traveled += current_speed * delta
	var mult := get_score_multiplier()
	score = int(distance_traveled * 2.2 * mult) + (run_coins * 15 * mult)
	score_updated.emit(score, mult)

	if chaser_danger_timer > 0.0:
		chaser_danger_timer = maxf(0.0, chaser_danger_timer - delta)

	_update_powerups(delta)

func _update_powerups(delta: float) -> void:
	if magnet_timer > 0.0:
		magnet_timer = max(0.0, magnet_timer - delta)
		powerup_updated.emit("KI MAGNET", magnet_timer, magnet_duration)
	if jetpack_timer > 0.0:
		jetpack_timer = max(0.0, jetpack_timer - delta)
		powerup_updated.emit("SUPER FLIGHT", jetpack_timer, jetpack_duration)
	if double_score_timer > 0.0:
		double_score_timer = max(0.0, double_score_timer - delta)
		powerup_updated.emit("2X ZENKAI", double_score_timer, double_score_duration)
	if sneakers_timer > 0.0:
		sneakers_timer = max(0.0, sneakers_timer - delta)
		powerup_updated.emit("POWER LEAP", sneakers_timer, sneakers_duration)

	if hoverboard_active:
		hoverboard_timer -= delta
		if hoverboard_timer <= 0.0:
			hoverboard_active = false
			shield_changed.emit(false, hoverboard_charges)

func is_super_mode_active() -> bool:
	return hoverboard_active or jetpack_timer > 0.0 or double_score_timer > 0.0

func get_score_multiplier() -> int:
	return 2 if double_score_timer > 0.0 else 1

func set_runner(runner_id: String) -> void:
	selected_runner = runner_id
	runner_changed.emit(selected_runner)
	save_data()

func start_new_run(start_world_idx: int = -1) -> void:
	if start_world_idx >= 0:
		selected_start_world = start_world_idx
	current_world_index = selected_start_world
	distance_traveled = 0.0
	next_world_distance = WORLD_SWITCH_DISTANCE
	score = 0
	run_coins = 0
	current_speed = BASE_RUN_SPEED
	chaser_danger_timer = 4.5

	magnet_timer = 0.0
	jetpack_timer = 0.0
	double_score_timer = 0.0
	sneakers_timer = 0.0

	hoverboard_charges = 2
	hoverboard_active = false
	hoverboard_timer = 0.0

	state = GameState.PLAYING
	get_tree().paused = false
	var w := WorldThemes.get_world(current_world_index)
	SoundManager.play_music(w.get("music_track", "run1"))
	world_changed.emit(current_world_index, w)
	coins_updated.emit(run_coins, total_coins)
	score_updated.emit(0, 1)
	shield_changed.emit(false, hoverboard_charges)
	game_started.emit()

func add_coin(amount: int = 1) -> void:
	run_coins += amount
	total_coins += amount
	coins_updated.emit(run_coins, total_coins)
	SoundManager.play_coin()

func activate_powerup(type: String) -> void:
	SoundManager.play_powerup()
	match type:
		"magnet":
			magnet_timer = magnet_duration
			powerup_updated.emit("KI MAGNET", magnet_timer, magnet_duration)
		"jetpack":
			jetpack_timer = jetpack_duration
			powerup_updated.emit("SUPER FLIGHT", jetpack_timer, jetpack_duration)
		"double_score":
			double_score_timer = double_score_duration
			powerup_updated.emit("2X ZENKAI", double_score_timer, double_score_duration)
		"sneakers":
			sneakers_timer = sneakers_duration
			powerup_updated.emit("POWER LEAP", sneakers_timer, sneakers_duration)

func try_activate_hoverboard() -> bool:
	if state != GameState.PLAYING:
		return false
	if hoverboard_active or hoverboard_charges <= 0:
		return false
	hoverboard_charges -= 1
	hoverboard_active = true
	hoverboard_timer = HOVERBOARD_DURATION
	shield_changed.emit(true, hoverboard_charges)
	SoundManager.play_powerup()
	return true

func consume_hoverboard_shield() -> bool:
	if hoverboard_active:
		hoverboard_active = false
		hoverboard_timer = 0.0
		shield_changed.emit(false, hoverboard_charges)
		SoundManager.play_shield_break()
		return true
	return false

func register_side_stumble() -> bool:
	if chaser_danger_timer > 0.5:
		return false
	chaser_danger_timer = 6.0
	SoundManager.play_shield_break()
	player_stumbled.emit()
	return true

func advance_to_next_world() -> void:
	if not world_tour_enabled:
		return
	current_world_index = (current_world_index + 1) % WorldThemes.get_worlds().size()
	next_world_distance = distance_traveled + WORLD_SWITCH_DISTANCE
	var w := WorldThemes.get_world(current_world_index)
	SoundManager.play_music(w.get("music_track", "run1"))
	world_changed.emit(current_world_index, w)
	SoundManager.play_portal()

func set_preview_world(index: int) -> void:
	selected_start_world = posmod(index, WorldThemes.get_worlds().size())
	current_world_index = selected_start_world
	world_changed.emit(current_world_index, WorldThemes.get_world(current_world_index))

func toggle_pause() -> void:
	if state == GameState.PLAYING:
		state = GameState.PAUSED
		get_tree().paused = true
		pause_toggled.emit(true)
	elif state == GameState.PAUSED:
		state = GameState.PLAYING
		get_tree().paused = false
		pause_toggled.emit(false)

func trigger_game_over() -> void:
	if state == GameState.GAMEOVER:
		return
	state = GameState.GAMEOVER
	SoundManager.play_crash()
	var is_new_record := false
	if score > high_score:
		high_score = score
		is_new_record = true
	save_data()
	game_over.emit(score, run_coins, is_new_record)

func save_data() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("progress", "high_score", high_score)
	cfg.set_value("progress", "total_coins", total_coins)
	cfg.set_value("progress", "selected_world", selected_start_world)
	cfg.set_value("progress", "selected_runner", selected_runner)
	cfg.set_value("audio", "music_muted", SoundManager.music_muted)
	cfg.save(SAVE_PATH)

func load_save_data() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) == OK:
		high_score = cfg.get_value("progress", "high_score", 0)
		total_coins = cfg.get_value("progress", "total_coins", 0)
		selected_start_world = cfg.get_value("progress", "selected_world", 0)
		selected_runner = cfg.get_value("progress", "selected_runner", "koku")
		current_world_index = selected_start_world
		var muted: bool = cfg.get_value("audio", "music_muted", false)
		SoundManager.set_music_muted(muted)
