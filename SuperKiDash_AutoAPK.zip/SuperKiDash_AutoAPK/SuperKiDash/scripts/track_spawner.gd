extends Node3D

const SEGMENT_LENGTH := 24.0
const NUM_SEGMENTS := 9

var _segments: Array[Node3D] = []
var _items: Array[Node3D] = []
var _portal_spawned_for_milestone: float = -1.0
var _pattern_counter: int = 0

@export var player_path: NodePath
var _player: Node3D

func _ready() -> void:
	if player_path != NodePath():
		_player = get_node(player_path)
	GameManager.game_started.connect(_reset_track)
	GameManager.world_changed.connect(_on_world_changed)
	_reset_track()

func _reset_track() -> void:
	for s in _segments:
		s.queue_free()
	_segments.clear()

	for item in _items:
		if is_instance_valid(item):
			item.queue_free()
	_items.clear()

	_portal_spawned_for_milestone = -1.0
	_pattern_counter = 0

	for i in range(NUM_SEGMENTS):
		var seg := _create_track_segment(i * -SEGMENT_LENGTH, i >= 2)
		add_child(seg)
		_segments.append(seg)

func _on_world_changed(_idx: int, _data: Dictionary) -> void:
	for seg in _segments:
		var z_pos := seg.position.z
		var idx := _segments.find(seg)
		var replacement := _create_track_segment(z_pos, false)
		add_child(replacement)
		_segments[idx] = replacement
		seg.queue_free()

func _process(delta: float) -> void:
	var speed := GameManager.current_speed if GameManager.state == GameManager.GameState.PLAYING else 12.0
	if GameManager.state == GameManager.GameState.GAMEOVER or GameManager.state == GameManager.GameState.PAUSED:
		return

	for seg in _segments:
		seg.position.z += speed * delta

	if _segments.size() > 0 and _segments[0].position.z > SEGMENT_LENGTH:
		var front_z := _segments[_segments.size() - 1].position.z
		var old_seg := _segments.pop_front()
		old_seg.queue_free()
		var new_seg := _create_track_segment(front_z - SEGMENT_LENGTH, GameManager.state == GameManager.GameState.PLAYING)
		add_child(new_seg)
		_segments.append(new_seg)

	var magnet_on := GameManager.magnet_timer > 0.0 and GameManager.state == GameManager.GameState.PLAYING
	var valid_items: Array[Node3D] = []
	for item in _items:
		if not is_instance_valid(item):
			continue
		var extra_speed: float = item.get_meta("extra_speed", 0.0) if GameManager.state == GameManager.GameState.PLAYING else 0.0
		item.position.z += (speed + extra_speed) * delta

		if item.get_meta("spin", false):
			item.rotation.y += delta * 3.4

		if magnet_on and item.get_meta("is_coin", false) and _player != null:
			if item.position.z > -24.0 and item.position.z < 4.0:
				var target := _player.global_position + Vector3(0, 1.0, 0)
				item.global_position = item.global_position.lerp(target, delta * 11.0)

		if item.position.z > 18.0:
			item.queue_free()
		else:
			valid_items.append(item)
	_items = valid_items

func _create_track_segment(z_pos: float, spawn_gameplay: bool) -> Node3D:
	var w := WorldThemes.get_world(GameManager.current_world_index)
	var seg := Node3D.new()
	seg.position = Vector3(0, 0, z_pos)

	var track_mat := CartoonFactory.make_toon_material(w["track_base"], 0.0, 0.0)
	var sleeper_mat := CartoonFactory.make_toon_material(w["sleeper_color"], 0.0, 0.0)
	var trim_mat := CartoonFactory.make_toon_material(w["track_trim"], 0.25 if w["id"] == "neon_cyber" else 0.0, 0.015)
	var wall_mat := CartoonFactory.make_toon_material(w["wall_color"], 0.0, 0.020)
	var rail_mat := CartoonFactory.make_toon_material(w["rail_color"], 0.35 if w["id"] == "neon_cyber" else 0.0, 0.0)
	var side_mat := CartoonFactory.make_toon_material(w["ground_side"], 0.0, 0.0)

	CartoonFactory.add_box(seg, Vector3(9.4, 0.4, SEGMENT_LENGTH), Vector3(0, -0.2, 0), track_mat)
	CartoonFactory.add_box(seg, Vector3(0.45, 0.45, SEGMENT_LENGTH), Vector3(-4.85, 0.12, 0), trim_mat)
	CartoonFactory.add_box(seg, Vector3(0.45, 0.45, SEGMENT_LENGTH), Vector3(4.85, 0.12, 0), trim_mat)
	CartoonFactory.add_box(seg, Vector3(0.75, 2.2, SEGMENT_LENGTH), Vector3(-5.45, 1.0, 0), wall_mat)
	CartoonFactory.add_box(seg, Vector3(0.75, 2.2, SEGMENT_LENGTH), Vector3(5.45, 1.0, 0), wall_mat)

	CartoonFactory.add_box(seg, Vector3(28.0, 0.3, SEGMENT_LENGTH), Vector3(-19.5, -0.25, 0), side_mat)
	CartoonFactory.add_box(seg, Vector3(28.0, 0.3, SEGMENT_LENGTH), Vector3(19.5, -0.25, 0), side_mat)

	for lane_x in GameManager.LANES:
		for tz in range(-10, 12, 3):
			CartoonFactory.add_box(seg, Vector3(1.55, 0.08, 0.36), Vector3(lane_x, 0.02, float(tz)), sleeper_mat)
		CartoonFactory.add_box(seg, Vector3(0.14, 0.10, SEGMENT_LENGTH), Vector3(lane_x - 0.56, 0.07, 0), rail_mat)
		CartoonFactory.add_box(seg, Vector3(0.14, 0.10, SEGMENT_LENGTH), Vector3(lane_x + 0.56, 0.07, 0), rail_mat)

	if int(absf(z_pos / SEGMENT_LENGTH)) % 2 == 0:
		var arch_mat := CartoonFactory.make_toon_material(Color(0.24, 0.28, 0.36), 0.0, 0.018)
		CartoonFactory.add_box(seg, Vector3(0.32, 6.2, 0.32), Vector3(-5.15, 3.1, 0), arch_mat)
		CartoonFactory.add_box(seg, Vector3(0.32, 6.2, 0.32), Vector3(5.15, 3.1, 0), arch_mat)
		CartoonFactory.add_box(seg, Vector3(10.8, 0.32, 0.32), Vector3(0, 6.1, 0), arch_mat)

	_populate_roadside_props(seg, w)

	if spawn_gameplay:
		if GameManager.world_tour_enabled and GameManager.distance_traveled >= GameManager.next_world_distance - 40.0 and _portal_spawned_for_milestone != GameManager.next_world_distance:
			_portal_spawned_for_milestone = GameManager.next_world_distance
			_spawn_world_portal(z_pos)
		else:
			_spawn_pattern(z_pos, w)

	return seg

func _populate_roadside_props(seg: Node3D, w: Dictionary) -> void:
	var colors: Array = w["building_colors"]
	var prop_type: String = w["prop_type"]

	for side in [-1.0, 1.0]:
		for step in [-6.0, 6.0]:
			var c: Color = colors[randi() % colors.size()]
			var mat := CartoonFactory.make_toon_material(c, 0.0, 0.022)
			var x_base := side * randf_range(8.2, 11.2)

			if prop_type == "subway_city":
				var h := randf_range(7.0, 15.0)
				CartoonFactory.add_box(seg, Vector3(4.2, h, 4.4), Vector3(x_base, h * 0.5, step), mat)
				var roof_mat := CartoonFactory.make_toon_material(c.darkened(0.25), 0.0, 0.020)
				CartoonFactory.add_box(seg, Vector3(4.5, 0.45, 4.7), Vector3(x_base, h + 0.2, step), roof_mat)
				var win_mat := CartoonFactory.make_toon_material(Color(1.0, 0.94, 0.58), 0.55, 0.0)
				for wy in [0.35, 0.58, 0.80]:
					CartoonFactory.add_box(seg, Vector3(4.32, 0.55, 3.2), Vector3(x_base, h * wy, step), win_mat)
				var awning_mat := CartoonFactory.make_toon_material(w["train_accent"], 0.0, 0.016)
				CartoonFactory.add_box(seg, Vector3(1.1, 0.35, 3.6), Vector3(x_base - side * 2.3, 2.8, step), awning_mat, Vector3(0, 0, side * 18.0))
			elif prop_type == "island":
				var roof_mat := CartoonFactory.make_toon_material(Color(0.92, 0.22, 0.24), 0.0, 0.020)
				CartoonFactory.add_cylinder(seg, 2.0, 2.1, 2.8, Vector3(x_base, 1.4, step), mat)
				CartoonFactory.add_cylinder(seg, 0.15, 2.45, 1.6, Vector3(x_base, 3.55, step), roof_mat)
				var trunk_mat := CartoonFactory.make_toon_material(Color(0.56, 0.34, 0.16), 0.0, 0.016)
				var leaf_mat := CartoonFactory.make_toon_material(Color(0.18, 0.78, 0.28), 0.0, 0.018)
				CartoonFactory.add_cylinder(seg, 0.18, 0.28, 4.4, Vector3(side * 6.5, 2.2, step + 2.5), trunk_mat, Vector3(0, 0, -side * 10.0))
				CartoonFactory.add_sphere(seg, 1.35, Vector3(side * 6.9, 4.5, step + 2.5), leaf_mat, Vector3(1.4, 0.5, 1.4))
			elif prop_type == "namek":
				CartoonFactory.add_sphere(seg, 2.2, Vector3(x_base, 1.5, step), mat, Vector3(1.1, 0.95, 1.1))
				var trunk_mat := CartoonFactory.make_toon_material(Color(0.76, 0.66, 0.44), 0.0, 0.016)
				var crown_mat := CartoonFactory.make_toon_material(Color(0.14, 0.72, 0.52), 0.0, 0.018)
				CartoonFactory.add_cylinder(seg, 0.22, 0.30, 5.4, Vector3(side * 6.6, 2.7, step - 2.0), trunk_mat)
				CartoonFactory.add_sphere(seg, 1.55, Vector3(side * 6.6, 5.8, step - 2.0), crown_mat)
			elif prop_type == "cyber":
				var h := randf_range(8.0, 18.0)
				CartoonFactory.add_box(seg, Vector3(4.0, h, 4.2), Vector3(x_base, h * 0.5, step), mat)
				var neon_mat := CartoonFactory.make_toon_material(Color(0.0, 0.96, 0.92), 0.85, 0.0)
				var pink_mat := CartoonFactory.make_toon_material(Color(1.0, 0.18, 0.68), 0.85, 0.0)
				CartoonFactory.add_box(seg, Vector3(4.15, 0.45, 3.6), Vector3(x_base, h * 0.68, step), neon_mat)
				CartoonFactory.add_box(seg, Vector3(0.35, 3.6, 1.4), Vector3(x_base - side * 2.15, h * 0.45, step), pink_mat)

func _spawn_pattern(z_pos: float, w: Dictionary) -> void:
	_pattern_counter += 1
	var pattern := _pattern_counter % 7
	var open_lane := randi() % 3

	if GameManager.jetpack_timer > 0.0:
		var sky_lane := randi() % 3
		_spawn_coin_line(GameManager.LANES[sky_lane], 6.2, z_pos, 5)
		return

	match pattern:
		0:
			for lane in range(3):
				if lane == open_lane:
					_spawn_coin_line(GameManager.LANES[lane], 0.9, z_pos, 4)
				else:
					var moving := (lane == (open_lane + 1) % 3) and GameManager.distance_traveled > 120.0
					_spawn_train(GameManager.LANES[lane], z_pos, w, moving)
		1:
			for lane in range(3):
				var lx := GameManager.LANES[lane]
				if lane == open_lane:
					_spawn_low_barrier(lx, z_pos, w)
					_spawn_coin_arc(lx, z_pos)
				elif lane == (open_lane + 1) % 3:
					_spawn_combo_barrier(lx, z_pos, w)
				else:
					_spawn_high_gate(lx, z_pos, w)
		2:
			for lane in range(3):
				var lx := GameManager.LANES[lane]
				if lane == open_lane:
					_spawn_high_gate(lx, z_pos, w)
					_spawn_coin_line(lx, 0.65, z_pos, 3)
				elif lane == (open_lane + 1) % 3:
					_spawn_train(lx, z_pos, w, false)
		3:
			var train_lane := randi() % 3
			_spawn_train(GameManager.LANES[train_lane], z_pos, w, false)
			var other_lane := (train_lane + 1) % 3
			_spawn_low_barrier(GameManager.LANES[other_lane], z_pos - 4.0, w)
			if randf() < 0.45:
				_spawn_powerup(GameManager.LANES[other_lane], 2.2, z_pos - 4.0)
			else:
				_spawn_coin_line(GameManager.LANES[(train_lane + 2) % 3], 0.9, z_pos, 4)
		4:
			for i in range(3):
				var lane_idx := (open_lane + i) % 3
				_spawn_low_barrier(GameManager.LANES[lane_idx], z_pos - 6.0 + (i * 6.0), w)
				_spawn_coin_line(GameManager.LANES[(lane_idx + 1) % 3], 0.9, z_pos - 6.0 + (i * 6.0), 2)
		5:
			var ramp_lane := open_lane
			var rx := GameManager.LANES[ramp_lane]
			_spawn_ramp(rx, z_pos + 6.5, w)
			_spawn_train(rx, z_pos - 1.5, w, false)
			_spawn_coin_line(rx, 3.45, z_pos - 1.5, 4)
			var side_lane := (ramp_lane + 1) % 3
			_spawn_train(GameManager.LANES[side_lane], z_pos - 1.5, w, false)
		6:
			var lane_a := open_lane
			var lane_b := (open_lane + 1) % 3
			_spawn_ramp(GameManager.LANES[lane_a], z_pos + 7.5, w)
			_spawn_train(GameManager.LANES[lane_a], z_pos + 0.5, w, false)
			_spawn_train(GameManager.LANES[lane_b], z_pos - 8.5, w, false)
			_spawn_coin_line(GameManager.LANES[lane_b], 3.45, z_pos - 8.5, 4)

func _spawn_train(x: float, z: float, w: Dictionary, is_moving: bool = false) -> void:
	var holder := Area3D.new()
	holder.position = Vector3(x, 0, z)
	holder.set_meta("kind", "obstacle")
	holder.set_meta("obs_type", "train")
	holder.set_meta("extra_speed", 13.5 if is_moving else 0.0)

	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(1.85, 2.55, 9.6)
	col.shape = shape
	col.position = Vector3(0, 1.3, 0)
	holder.add_child(col)

	var main_col: Color = w["train_secondary"] if is_moving else w["train_primary"]
	var body_mat := CartoonFactory.make_toon_material(main_col, 0.0, 0.022)
	var stripe_mat := CartoonFactory.make_toon_material(w["train_accent"], 0.25 if w["id"] == "neon_cyber" else 0.0, 0.015)
	var roof_mat := CartoonFactory.make_toon_material(Color(0.95, 0.97, 1.0), 0.0, 0.020)
	var glass_mat := CartoonFactory.make_toon_material(Color(0.14, 0.22, 0.34), 0.15, 0.012)
	var light_mat := CartoonFactory.make_toon_material(Color(1.0, 0.96, 0.45), 1.2 if is_moving else 0.7, 0.0)

	CartoonFactory.add_box(holder, Vector3(1.98, 2.42, 9.8), Vector3(0, 1.28, 0), body_mat)
	CartoonFactory.add_box(holder, Vector3(2.04, 0.38, 9.86), Vector3(0, 1.05, 0), stripe_mat)
	CartoonFactory.add_box(holder, Vector3(1.78, 0.24, 9.5), Vector3(0, 2.58, 0), roof_mat)

	CartoonFactory.add_box(holder, Vector3(1.56, 0.78, 0.12), Vector3(0, 1.82, 4.92), glass_mat)
	CartoonFactory.add_box(holder, Vector3(2.03, 0.64, 7.6), Vector3(0, 1.76, 0), glass_mat)

	CartoonFactory.add_sphere(holder, 0.20, Vector3(-0.58, 0.68, 4.94), light_mat)
	CartoonFactory.add_sphere(holder, 0.20, Vector3(0.58, 0.68, 4.94), light_mat)

	var roof_body := StaticBody3D.new()
	var roof_col := CollisionShape3D.new()
	var roof_shape := BoxShape3D.new()
	roof_shape.size = Vector3(1.98, 0.25, 9.8)
	roof_col.shape = roof_shape
	roof_col.position = Vector3(0, 2.55, 0)
	roof_body.add_child(roof_col)
	holder.add_child(roof_body)

	add_child(holder)
	_items.append(holder)

func _spawn_ramp(x: float, z: float, w: Dictionary) -> void:
	var ramp := StaticBody3D.new()
	ramp.position = Vector3(x, 0, z)

	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(1.92, 0.35, 6.2)
	col.shape = shape
	col.position = Vector3(0, 1.25, 0)
	col.rotation_degrees = Vector3(24.5, 0, 0)
	ramp.add_child(col)

	var ramp_mat := CartoonFactory.make_toon_material(w["train_accent"], 0.15, 0.020)
	CartoonFactory.add_box(ramp, Vector3(1.92, 0.35, 6.2), Vector3(0, 1.25, 0), ramp_mat, Vector3(24.5, 0, 0))

	add_child(ramp)
	_items.append(ramp)

func _spawn_low_barrier(x: float, z: float, w: Dictionary) -> void:
	var holder := Area3D.new()
	holder.position = Vector3(x, 0, z)
	holder.set_meta("kind", "obstacle")
	holder.set_meta("obs_type", "low_barrier")

	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(1.85, 0.92, 0.65)
	col.shape = shape
	col.position = Vector3(0, 0.48, 0)
	holder.add_child(col)

	var bar_mat := CartoonFactory.make_toon_material(w["barrier_color"], 0.0, 0.018)
	var white_mat := CartoonFactory.make_toon_material(Color(0.98, 0.98, 0.98), 0.0, 0.018)

	CartoonFactory.add_box(holder, Vector3(0.22, 0.95, 0.22), Vector3(-0.78, 0.48, 0), white_mat)
	CartoonFactory.add_box(holder, Vector3(0.22, 0.95, 0.22), Vector3(0.78, 0.48, 0), white_mat)
	CartoonFactory.add_box(holder, Vector3(1.94, 0.42, 0.28), Vector3(0, 0.74, 0), bar_mat)
	CartoonFactory.add_box(holder, Vector3(0.65, 0.44, 0.30), Vector3(0, 0.74, 0), white_mat)

	add_child(holder)
	_items.append(holder)

func _spawn_combo_barrier(x: float, z: float, w: Dictionary) -> void:
	var holder := Area3D.new()
	holder.position = Vector3(x, 0, z)
	holder.set_meta("kind", "obstacle")
	holder.set_meta("obs_type", "combo_barrier")

	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(1.85, 0.55, 0.65)
	col.shape = shape
	col.position = Vector3(0, 1.05, 0)
	holder.add_child(col)

	var post_mat := CartoonFactory.make_toon_material(Color(0.96, 0.96, 0.98), 0.0, 0.018)
	var bar_mat := CartoonFactory.make_toon_material(w["barrier_color"], 0.0, 0.018)
	CartoonFactory.add_box(holder, Vector3(0.22, 1.45, 0.22), Vector3(-0.82, 0.72, 0), post_mat)
	CartoonFactory.add_box(holder, Vector3(0.22, 1.45, 0.22), Vector3(0.82, 0.72, 0), post_mat)
	CartoonFactory.add_box(holder, Vector3(1.98, 0.44, 0.28), Vector3(0, 1.08, 0), bar_mat)

	add_child(holder)
	_items.append(holder)

func _spawn_high_gate(x: float, z: float, w: Dictionary) -> void:
	var holder := Area3D.new()
	holder.position = Vector3(x, 0, z)
	holder.set_meta("kind", "obstacle")
	holder.set_meta("obs_type", "high_gate")

	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(1.85, 1.55, 0.65)
	col.shape = shape
	col.position = Vector3(0, 1.85, 0)
	holder.add_child(col)

	var post_mat := CartoonFactory.make_toon_material(Color(0.85, 0.88, 0.92), 0.0, 0.018)
	var sign_mat := CartoonFactory.make_toon_material(w["barrier_color"], 0.0, 0.020)
	var arrow_mat := CartoonFactory.make_toon_material(Color(1.0, 0.88, 0.14), 0.35, 0.0)

	CartoonFactory.add_box(holder, Vector3(0.20, 2.75, 0.20), Vector3(-0.88, 1.38, 0), post_mat)
	CartoonFactory.add_box(holder, Vector3(0.20, 2.75, 0.20), Vector3(0.88, 1.38, 0), post_mat)
	CartoonFactory.add_box(holder, Vector3(2.05, 1.25, 0.32), Vector3(0, 2.05, 0), sign_mat)
	CartoonFactory.add_box(holder, Vector3(1.35, 0.28, 0.36), Vector3(0, 1.80, 0), arrow_mat)

	add_child(holder)
	_items.append(holder)

func _spawn_coin_line(x: float, y: float, z_center: float, count: int) -> void:
	var orb_mat := CartoonFactory.make_toon_material(Color(1.0, 0.72, 0.08), 0.45, 0.016)
	for i in range(count):
		var offset := (i - (count - 1) * 0.5) * 2.1
		_create_single_coin(Vector3(x, y, z_center + offset), orb_mat)

func _spawn_coin_arc(x: float, z_center: float) -> void:
	var orb_mat := CartoonFactory.make_toon_material(Color(1.0, 0.72, 0.08), 0.45, 0.016)
	var offsets := [-3.6, -1.8, 0.0, 1.8, 3.6]
	var heights := [0.9, 1.95, 2.45, 1.95, 0.9]
	for i in range(offsets.size()):
		_create_single_coin(Vector3(x, heights[i], z_center + offsets[i]), orb_mat)

func _create_single_coin(pos: Vector3, mat: Material) -> void:
	var orb := Area3D.new()
	orb.position = pos
	orb.set_meta("kind", "coin")
	orb.set_meta("is_coin", true)
	orb.set_meta("spin", true)

	var col := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 0.55
	col.shape = shape
	orb.add_child(col)

	CartoonFactory.add_sphere(orb, 0.36, Vector3.ZERO, mat)
	add_child(orb)
	_items.append(orb)

func _spawn_powerup(x: float, y: float, z: float) -> void:
	var types := ["magnet", "jetpack", "double_score", "sneakers"]
	var ptype: String = types[randi() % types.size()]
	var colors := {
		"magnet": Color(0.98, 0.18, 0.28),
		"jetpack": Color(0.14, 0.86, 1.0),
		"double_score": Color(1.0, 0.86, 0.12),
		"sneakers": Color(0.22, 0.94, 0.34)
	}

	var item := Area3D.new()
	item.position = Vector3(x, y, z)
	item.set_meta("kind", "powerup")
	item.set_meta("powerup_type", ptype)
	item.set_meta("spin", true)

	var col := CollisionShape3D.new()
	var shape := SphereShape3D.new()
	shape.radius = 0.72
	col.shape = shape
	item.add_child(col)

	var mat := CartoonFactory.make_toon_material(colors[ptype], 0.65, 0.018)
	var ring_mat := CartoonFactory.make_toon_material(Color(1.0, 0.96, 0.45), 0.5, 0.012)
	CartoonFactory.add_sphere(item, 0.48, Vector3.ZERO, mat)
	CartoonFactory.add_box(item, Vector3(1.12, 0.14, 0.14), Vector3.ZERO, ring_mat, Vector3(0, 0, 35))
	CartoonFactory.add_box(item, Vector3(1.12, 0.14, 0.14), Vector3.ZERO, ring_mat, Vector3(0, 0, -35))

	add_child(item)
	_items.append(item)

func _spawn_world_portal(z: float) -> void:
	var next_idx := (GameManager.current_world_index + 1) % WorldThemes.get_worlds().size()
	var next_w := WorldThemes.get_world(next_idx)

	var portal := Area3D.new()
	portal.position = Vector3(0, 0, z)
	portal.set_meta("kind", "portal")

	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(8.8, 7.0, 1.6)
	col.shape = shape
	col.position = Vector3(0, 3.5, 0)
	portal.add_child(col)

	var arch_mat := CartoonFactory.make_toon_material(next_w["train_accent"], 0.85, 0.020)
	var glow_mat := CartoonFactory.make_toon_material(next_w["sky_top"], 0.75, 0.0)

	CartoonFactory.add_box(portal, Vector3(0.65, 5.4, 0.65), Vector3(-4.3, 2.7, 0), arch_mat)
	CartoonFactory.add_box(portal, Vector3(0.65, 5.4, 0.65), Vector3(4.3, 2.7, 0), arch_mat)
	CartoonFactory.add_box(portal, Vector3(9.4, 0.75, 0.75), Vector3(0, 5.3, 0), arch_mat)
	CartoonFactory.add_box(portal, Vector3(8.2, 4.9, 0.12), Vector3(0, 2.6, 0), glow_mat)

	add_child(portal)
	_items.append(portal)
